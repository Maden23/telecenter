#include <iostream>
#include <string>
#include <unistd.h>


using namespace std;

class Player
{
public:
	Player();
	// ~Player();
	void playStream(string uri);
private:
	string uri;
	
};