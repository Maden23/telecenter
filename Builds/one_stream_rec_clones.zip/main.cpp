#include <iostream>
#include <string>
#include "recorder_core.h"
#include "player.h"

using namespace std;

int main()
{
	string uri = "rtsp://admin:Supervisor@172.18.200.51:554";
    string saveToFolder = "/home/petr/controlroom/videos/";

	RecorderCore recorder(uri, saveToFolder);

	int streams;
	cout << "Number of streams: ";
	cin >> streams;

	std::vector<pid_t> pids = recorder.forkRecorder(streams);

	Player player;
	player.playStream(uri);


	for (auto &pid : pids)
	{
		int status;
		while(waitpid(pid, &status, 0) == -1);
	}
}