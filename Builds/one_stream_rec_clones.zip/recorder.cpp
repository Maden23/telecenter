#include "recorder_core.h"

Recorder::Recorder(string uri, string saveToFolder)
{
    this->uri = uri;
    this->saveToFolder = saveToFolder;
}

Recorder::~Recorder()
{
    for (auto pid : runningRecorders)
    {
        cerr << " Killing process " << pid << endl;
        kill(pid, SIGINT);
        waitpid(pid, nullptr, 0);
        pid = -1;
    }
}

std::vector<pid_t> Recorder::forkRecorder(int streamsNum)
{
    for (int i = 0; i < streamsNum; i++)
    {
        pid_t pid = fork();
    
        if (pid == -1) {
            cerr << "Couldn't fork" << endl;
            perror("fork");
        }

        if (pid == 0) {
            string logsFile = saveToFolder + "logs/" + to_string(getpid()) + ".logs";

            int fd = open(logsFile.c_str(), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);

            if(fd == -1) {
                perror("logs");
            }



            dup2(fd, 1);
            dup2(fd, 2);

            string fileName = saveToFolder + to_string(getpid()) + ".mp4"; 
            cout << fileName << endl;

            execlp("gst-launch-1.0", "-e", "rtspsrc", ("location=" + uri).c_str(),
           "protocols=tcp", "!", "rtph264depay", "name=vdepay", "!", "mpegtsmux", "name=mux", 
           "!", "filesink", ("location=" + fileName).c_str(), nullptr);

        }
        else
        {
            runningRecorders.push_back(pid);
        }
    }
    return runningRecorders;
}