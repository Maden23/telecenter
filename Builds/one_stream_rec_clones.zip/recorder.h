#include <iostream>
#include <vector>
#include <string>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <wait.h>

using namespace std; 


class Recorder
{
public:
    Recorder(string uri, string saveToFolder);
    ~Recorder();
    vector<pid_t> forkRecorder(int streamsNum);
    
private:
    vector<pid_t> runningRecorders; 
    string uri;
    string saveToFolder;
};