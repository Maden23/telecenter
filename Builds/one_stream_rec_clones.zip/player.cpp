#include "player.h"

Player::Player()
{

}

void Player::playStream(string uri)
{
	execlp("gst-launch-1.0", "-e", "playbin", ("uri=" + uri).c_str(), nullptr);
}